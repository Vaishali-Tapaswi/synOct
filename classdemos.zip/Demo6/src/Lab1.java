import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Lab1 {

	public static void main(String[] args) {
		System.out.println("Press a number to continue");
		Scanner scanner = new Scanner(System.in);
		scanner.nextInt();
	
		List<Integer> list = new ArrayList<Integer>();
		for (int i = 0; i< 999000;i++)
		{
			list.add((int)(Math.random()*1000));
		}
		list.forEach(System.out::println);
	//	list.stream()
		list.parallelStream().filter((x)->x<600 && x>200).forEach(System.out::println);
	}
	}

