class Lab1Support extends Thread{
	@Override
	public void run() {
		for (int i = 0;i< 15;i++){
			System.out.println("Thread " + Thread.currentThread().getName() + ", i = "  + i);
		}
	}
}

public class Lab1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Lab1Support t1 = new Lab1Support();
		t1.setDaemon(true);
		t1.start();
		System.out.println("End of Main");
	}

}
