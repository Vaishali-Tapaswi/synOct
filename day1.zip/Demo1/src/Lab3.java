import java.util.Scanner;

public class Lab3 {
	
	public static void main(String[] args) {
		System.out.println("Press a number to continue");
		Scanner scanner = new Scanner(System.in);
		scanner.nextInt();
		Runnable runnable1 = ()->{	for (int i = 0;i<15;i++){
			System.out.println("---- " + i +  " in thread " + Thread.currentThread().getName());
		}};
		Runnable runnable2 = ()->{	for (int i = 0;i<15;i++){
			System.out.println("***" + i +  " in thread " + Thread.currentThread().getName());
		}};
		
		Runnable runnable3 = ()->{	for (int i = 0;i<15;i++){
			System.out.println("xxx" + i +  " in thread " + Thread.currentThread().getName());
		}};
		
		Thread t1 = new Thread(runnable1);
		t1.setPriority(Thread.MAX_PRIORITY);
		Thread t3 = new Thread(runnable3);
		Thread t2 = new Thread(runnable2);
		t1.start();
		t2.start();
		t3.start();
		

	}
}
