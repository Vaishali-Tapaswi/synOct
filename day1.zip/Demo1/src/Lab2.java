import java.util.Scanner;

class Lab2Support implements Runnable
{
@Override
public void run() {
	for (int i = 0;i<10;i++){
		System.out.println("For - " + i +  " in thread " + Thread.currentThread().getName());
	}
}	
}
public class Lab2 {

	
	public static void main(String[] args) {
		System.out.println("Press a number to continue");
		Scanner scanner = new Scanner(System.in);
		scanner.nextInt();
		Thread t1 = new Thread(new Lab2Support());
		t1.start();
		
		System.out.println("after starting the thread");

	}
}
